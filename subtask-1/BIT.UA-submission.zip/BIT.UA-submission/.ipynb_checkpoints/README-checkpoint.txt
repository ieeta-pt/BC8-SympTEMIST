Team: BIT.UA
Affiliation: IEETA, University of Aveiro
Contact email: tiagomeloalmeida@ua.pt

Description: We explored a transformer-based solution with masked CRF and data augmentation. Specially, we deeply explored the impact of our random augmentation techniques on the model performance.

1-system-all: ensemble of all the trained models
2-system-best: best model on the validation set
3-system-top5: ensemble of the top-5 best models on the validation set
4-system-all-random: ensemble of all the models trained with random token augmentation
5-system-all-unk: ensemble of all the models trained with unknown token augmentation